'use client';
import { useRouter } from 'next/navigation';

export default function HeroSection({ searchQuery, onSearchChange, onSearch }) {
  const router = useRouter();
  
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') onSearch();
  };

  return (
    <div className="hero">
      <h1>#1 Source For Premium<br/>Courses</h1>
      <p>All Kind of Courses Available at Cheap Prices.</p>
      <div className="search-container">
        <input 
          type="text" 
          className="search-input" 
          placeholder="Search" 
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <button className="search-btn" onClick={onSearch}>
          <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
        </button>
      </div>
      <button className="btn-shop" onClick={() => router.push('/shop')}>Go to Shop &rarr;</button>
    </div>
  );
}
